package ar.edu.unlam.pb2;

import ar.edu.unlam.pb2.interfaces.FlojoDePapelesException;
import ar.edu.unlam.pb2.interfaces.Multeable;
import ar.edu.unlam.pb2.interfaces.NoRespetoSemaforoException;
import ar.edu.unlam.pb2.interfaces.PesoMaximoException;
import ar.edu.unlam.pb2.interfaces.VelocidadMaximaException;

public class Moto extends MedioTransporte implements Multeable{

	private String patente;
	private Integer cantpasajeros;
	private Integer velocidadmaxima;
	private Double latitud;
	private Double longitud;
	private Integer velocidadactual;
	private Integer pesomaximo;


	
	
	public Moto(String patente, int velocidadmaxima, double latitud, 
			double longitud) {

		this.patente=patente;
		this.velocidadmaxima=velocidadmaxima;
		this.latitud=latitud;
		this.longitud=longitud;
	}


	public String getPatente() {
		return patente;
	}


	public void setPatente(String patente) {
		this.patente = patente;
	}


	public Integer getCAPACIDA_MAXIMA_DE_PASAJEROS() {
		return cantpasajeros;
	}


	public void setCantpasajeros(Integer cantpasajeros) {
		this.cantpasajeros = cantpasajeros;
	}


	public Integer getVelocidadMaximaPermitida() {
		return velocidadmaxima;
	}


	public void setVelocidadmaxima(Integer velocidadmaxima) {
		this.velocidadmaxima = velocidadmaxima;
	}


	public Double getLatitud() {
		return latitud;
	}


	public void setLatitud(Double latitud) {
		this.latitud = latitud;
	}


	public Double getLongitud() {
		return longitud;
	}


	public void setLongitud(Double longitud) {
		this.longitud = longitud;
	}


	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((patente == null) ? 0 : patente.hashCode());
		return result;
	}


	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Moto other = (Moto) obj;
		if (patente == null) {
			if (other.patente != null)
				return false;
		} else if (!patente.equals(other.patente))
			return false;
		return true;
	}


	public int compareTo(MedioTransporte o) {
		// TODO Auto-generated method stub
		
		return 0;
	}


	public Boolean superoVelocidadMaxima() throws VelocidadMaximaException {
		// TODO Auto-generated method stub
		if(velocidadactual>velocidadmaxima)
		{
			throw new VelocidadMaximaException();
			
		}
		return null;
	}


	public Boolean superoPesoMaximoCarga() throws PesoMaximoException {
		// TODO Auto-generated method stub
		return null;
	}


	public Boolean cruzoEnRojo() throws NoRespetoSemaforoException {
		// TODO Auto-generated method stub
		return null;
	}


	public Boolean estaEnRegla() throws FlojoDePapelesException {
		// TODO Auto-generated method stub
		return null;
	}

	
	
	
	
}
