package ar.edu.unlam.pb2;

import java.util.HashSet;
import java.util.Iterator;
import java.util.TreeSet;

public class Mapa {

	private HashSet<MedioTransporte> vehiculos = new HashSet<MedioTransporte>();
	public Mapa(String string) {
		// TODO Auto-generated constructor stub
	}

	public void agregarVehiculo(MedioTransporte vehi) {
	
		vehiculos.add(vehi);
		
	}

	public Integer getCantidadDeVehiculos() {
		// TODO Auto-generated method stub
		return vehiculos.size();
	}

	public boolean hayCoalici�n() throws ColitionException {
		Iterator <MedioTransporte> it= vehiculos.iterator();
		Iterator <MedioTransporte> ite= vehiculos.iterator();
		
		while(it.hasNext())
		{
			
		Double latitud= it.next().getLatitud();
		Double longitud= it.next().getLongitud();
		
		while(ite.hasNext())
		{
		Double latitud2= it.next().getLatitud();
		Double longitud2= it.next().getLongitud();
			
			if(latitud.equals(latitud2))
			{
				if(longitud.equals(longitud2))
			{
				
					throw new ColitionException();
				
				
			}
				
			}else return false;
		
			
			
		}
		
		
		}
		
		
		
		return false;
	}

}
