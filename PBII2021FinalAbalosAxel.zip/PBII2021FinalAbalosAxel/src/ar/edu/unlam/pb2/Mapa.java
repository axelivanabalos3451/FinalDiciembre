package ar.edu.unlam.pb2;

import java.util.HashSet;
import java.util.Iterator;
import java.util.TreeSet;

public class Mapa {

	private HashSet<MedioTransporte> vehiculos = new HashSet<MedioTransporte>();
	public Mapa(String string) {
		// TODO Auto-generated constructor stub
	}

	public void agregarVehiculo(MedioTransporte vehi) {
	
		vehiculos.add(vehi);
		
	}

	public Integer getCantidadDeVehiculos() {
		// TODO Auto-generated method stub
		return vehiculos.size();
	}

	public boolean hayCoalici�n() throws ColitionException {
		
		HashSet<MedioTransporte> vehiculos2 = new HashSet<MedioTransporte>();
		vehiculos2.addAll(vehiculos);
		Iterator <MedioTransporte> it= vehiculos.iterator();
		Iterator <MedioTransporte> it2= vehiculos2.iterator();
		
		while(it.hasNext())
		{
			
			while(it2.hasNext())
			{
			if(it.next().getLatitud().equals(it2.next().getLatitud()))
			{
				if(it.next().getLongitud().equals(it2.next().getLongitud()));
				
				throw new ColitionException();
			}
				
			}
			
		}

		
		/*while(it.hasNext())
		{
			
		Double latitud= it.next().getLatitud();
		Double longitud= it.next().getLongitud();
		
		while(ite.hasNext())
		{
		Double latitud2= ite.next().getLatitud();
		Double longitud2= ite.next().getLongitud();
			
			if(latitud.equals(latitud2))
			{
				if(longitud.equals(longitud2))
			{
				
					throw new ColitionException();
				
				
			}
				
			} return false;
		
			
			
		}
		
		
		}*/
		
		
		
		return false;
	}

}
