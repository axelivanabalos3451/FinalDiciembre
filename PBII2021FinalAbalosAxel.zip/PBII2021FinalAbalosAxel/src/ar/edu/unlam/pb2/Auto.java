package ar.edu.unlam.pb2;

import ar.edu.unlam.pb2.interfaces.FlojoDePapelesException;
import ar.edu.unlam.pb2.interfaces.Multeable;
import ar.edu.unlam.pb2.interfaces.NoRespetoSemaforoException;
import ar.edu.unlam.pb2.interfaces.PesoMaximoException;
import ar.edu.unlam.pb2.interfaces.VelocidadMaximaException;

public class Auto extends MedioTransporte implements Multeable{
	private String patente;
	private Integer cantpasajeros;
	private Integer velocidadmaxima;
	private Double latitud;
	private Double longitud;
	private Integer velocidadactual;
	private Integer pesomaximo;

	public Auto(String patente, int cantpasajeros, int velocidadmaxima, double latitud, double longitud) {

		this.patente=patente;
		this.cantpasajeros=cantpasajeros;
		this.velocidadmaxima=velocidadmaxima;
		this.latitud=latitud;
		this.longitud=longitud;
		
	
	}

	public String getPatente() {
		return patente;
	}

	public void setPatente(String patente) {
		this.patente = patente;
	}

	public Integer getCantidadMaximaDePasajeros() {
		return cantpasajeros;
	}

	public void setCantpasajeros(Integer cantpasajeros) {
		this.cantpasajeros = cantpasajeros;
	}

	public Integer getVelocidadMaximaPermitida() {
		return velocidadmaxima;
	}

	public void setVelocidadmaxima(Integer velocidadmaxima) {
		this.velocidadmaxima = velocidadmaxima;
	}

	public Double getLatitud() {
		return latitud;
	}

	public void setLatitud(Double latitud) {
		this.latitud = latitud;
	}

	public Double getLongitud() {
		return longitud;
	}

	public void setLongitud(Double longitud) {
		this.longitud = longitud;
	}

	public Integer getVelocidadActual() {
		return velocidadactual;
	}

	public void setVelocidadactual(Integer velocidadactual) {
		this.velocidadactual = velocidadactual;
	}

	public int compareTo(MedioTransporte o) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((cantpasajeros == null) ? 0 : cantpasajeros.hashCode());
		result = prime * result + ((latitud == null) ? 0 : latitud.hashCode());
		result = prime * result + ((longitud == null) ? 0 : longitud.hashCode());
		result = prime * result + ((patente == null) ? 0 : patente.hashCode());
		result = prime * result + ((velocidadactual == null) ? 0 : velocidadactual.hashCode());
		result = prime * result + ((velocidadmaxima == null) ? 0 : velocidadmaxima.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Auto other = (Auto) obj;
		if (cantpasajeros == null) {
			if (other.cantpasajeros != null)
				return false;
		} else if (!cantpasajeros.equals(other.cantpasajeros))
			return false;
		if (latitud == null) {
			if (other.latitud != null)
				return false;
		} else if (!latitud.equals(other.latitud))
			return false;
		if (longitud == null) {
			if (other.longitud != null)
				return false;
		} else if (!longitud.equals(other.longitud))
			return false;
		if (patente == null) {
			if (other.patente != null)
				return false;
		} else if (!patente.equals(other.patente))
			return false;
		if (velocidadactual == null) {
			if (other.velocidadactual != null)
				return false;
		} else if (!velocidadactual.equals(other.velocidadactual))
			return false;
		if (velocidadmaxima == null) {
			if (other.velocidadmaxima != null)
				return false;
		} else if (!velocidadmaxima.equals(other.velocidadmaxima))
			return false;
		return true;
	}

	public Boolean superoVelocidadMaxima() throws VelocidadMaximaException {
		if(velocidadactual>velocidadmaxima)
		{
			throw new VelocidadMaximaException();
			
		}

		return null;
	}

	public Boolean superoPesoMaximoCarga() throws PesoMaximoException {
		// TODO Auto-generated method stub
	
		
		return null;
	}

	public Boolean cruzoEnRojo() throws NoRespetoSemaforoException {
		// TODO Auto-generated method stub
		return null;
	}

	public Boolean estaEnRegla() throws FlojoDePapelesException {
		// TODO Auto-generated method stub
		return null;
	}
	
	
	
	
	
	
	
	
	
	
	
	

}
