package ar.edu.unlam.pb2;

public class Tren extends MedioTransporte implements Comparable<MedioTransporte> {
	private Integer cantvagones;
	private Integer cantpasajerosvagon;
	private Integer velocidadmaxima;
	private double latitud;
	private double longitud;
	

	public Tren(int cantvagones, int cantpasajerosvagon, int velocidadmaxima, 
			double latitud, double longitud) {
		this.cantvagones=cantvagones;
		this.cantpasajerosvagon=cantpasajerosvagon;
		this.velocidadmaxima=velocidadmaxima;
		this.latitud=latitud;
		this.longitud=longitud;
		

	}


	public Integer getCantidadDeVagones() {
		return cantvagones;
	}


	public void setCantvagones(Integer cantvagones) {
		this.cantvagones = cantvagones;
	}


	public Integer getCantidadDePasajerosPorVagon() {
		return cantpasajerosvagon;
	}


	public void setCantpasajerosvagon(Integer cantpasajerosvagon) {
		this.cantpasajerosvagon = cantpasajerosvagon;
	}


	public Integer getVelocidadMaximaPermitida() {
		return velocidadmaxima;
	}


	public void setVelocidadmaxima(Integer velocidadmaxima) {
		this.velocidadmaxima = velocidadmaxima;
	}


	public Double getLatitud() {
		return latitud;
	}


	public void setLatitud(double latitud) {
		this.latitud = latitud;
	}


	public Double getLongitud() {
		return longitud;
	}


	public void setLongitud(double longitud) {
		this.longitud = longitud;
	}


	public int compareTo(MedioTransporte o) {
		// TODO Auto-generated method stub
		return 0;
	}

	
	
	
	
	
	
	
}
