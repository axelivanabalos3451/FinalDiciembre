package ar.edu.unlam.pb2.interfaces;

public class NoRespetoSemaforoException extends Exception {

}
