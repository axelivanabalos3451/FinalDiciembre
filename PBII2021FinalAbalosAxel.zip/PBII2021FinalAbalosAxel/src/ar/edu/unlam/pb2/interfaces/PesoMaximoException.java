package ar.edu.unlam.pb2.interfaces;

public class PesoMaximoException extends Exception {

}
