package ar.edu.unlam.pb2.interfaces;

public class FlojoDePapelesException extends Exception {

}
