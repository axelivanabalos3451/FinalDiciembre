package ar.edu.unlam.pb2.interfaces;

public class VelocidadMaximaException extends Exception {
	public static void method()
{

}
}
