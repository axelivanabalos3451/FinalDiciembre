package ar.edu.unlam.pb2;

import ar.edu.unlam.pb2.interfaces.FlojoDePapelesException;
import ar.edu.unlam.pb2.interfaces.Multeable;
import ar.edu.unlam.pb2.interfaces.NoRespetoSemaforoException;
import ar.edu.unlam.pb2.interfaces.PesoMaximoException;
import ar.edu.unlam.pb2.interfaces.VelocidadMaximaException;

public class Camion extends MedioTransporte implements  Multeable {

	private String patente;
	private Integer velocidadmaxima;
	private Integer pesomaximo;
	private Double latitud;
	private Double longitud;
	private Integer velocidadactual;
	private Integer Peso;
	
	
	
	public Camion(String patente, int velocidadmaxima, int pesomaximo,
			double latitud, double longitud) {

		this.patente=patente;
		this.velocidadmaxima=velocidadmaxima;
		this.pesomaximo=pesomaximo;
		this.latitud=latitud;
		this.longitud=longitud;
		

	}
	
	
	
	
	public String getPatente() {
		return patente;
	}


	public void setPatente(String patente) {
		this.patente = patente;
	}


	public Integer getPesomaximo() {
		return pesomaximo;
	}




	public void setPesomaximo(Integer pesomaximo) {
		this.pesomaximo = pesomaximo;
	}




	public Integer getVelocidadactual() {
		return velocidadactual;
	}




	public void setVelocidadactual(Integer velocidadactual) {
		this.velocidadactual = velocidadactual;
	}




	public Integer getPeso() {
		return Peso;
	}




	public void setPeso(Integer peso) {
		Peso = peso;
	}




	public Integer getVelocidadmaxima() {
		return velocidadmaxima;
	}




	public Integer getVelocidadMaximaPermitida() {
		return velocidadmaxima;
	}


	public void setVelocidadmaxima(Integer velocidadmaxima) {
		this.velocidadmaxima = velocidadmaxima;
	}


	public Integer getPesoMaximoPermitido() {
		return pesomaximo;
	}


	public void setPesoMaximo(Integer pesoMaximo) {
		this.pesomaximo = pesoMaximo;
	}


	public Double getLatitud() {
		return latitud;
	}


	public void setLatitud(Double latitud) {
		this.latitud = latitud;
	}


	public Double getLongitud() {
		return longitud;
	}


	public void setLongitud(Double longitud) {
		this.longitud = longitud;
	}




	public int compareTo(MedioTransporte o) {
		// TODO Auto-generated method stub
		return 0;
	}




	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((latitud == null) ? 0 : latitud.hashCode());
		result = prime * result + ((longitud == null) ? 0 : longitud.hashCode());
		result = prime * result + ((patente == null) ? 0 : patente.hashCode());
		result = prime * result + ((pesomaximo == null) ? 0 : pesomaximo.hashCode());
		result = prime * result + ((velocidadmaxima == null) ? 0 : velocidadmaxima.hashCode());
		return result;
	}




	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Camion other = (Camion) obj;
		if (latitud == null) {
			if (other.latitud != null)
				return false;
		} else if (!latitud.equals(other.latitud))
			return false;
		if (longitud == null) {
			if (other.longitud != null)
				return false;
		} else if (!longitud.equals(other.longitud))
			return false;
		if (patente == null) {
			if (other.patente != null)
				return false;
		} else if (!patente.equals(other.patente))
			return false;
		if (pesomaximo == null) {
			if (other.pesomaximo != null)
				return false;
		} else if (!pesomaximo.equals(other.pesomaximo))
			return false;
		if (velocidadmaxima == null) {
			if (other.velocidadmaxima != null)
				return false;
		} else if (!velocidadmaxima.equals(other.velocidadmaxima))
			return false;
		return true;
	}




	public Boolean superoVelocidadMaxima() throws VelocidadMaximaException {
		
		if(velocidadactual>velocidadmaxima)
		{
			throw new VelocidadMaximaException();
			
		}
		
		
		return null;
	}




	public Boolean superoPesoMaximoCarga() throws PesoMaximoException {
		
		if(pesomaximo<Peso)
		{
			throw new PesoMaximoException();
		}
		return null;
	}




	public Boolean cruzoEnRojo() throws NoRespetoSemaforoException {
		// TODO Auto-generated method stub
		return null;
	}




	public Boolean estaEnRegla() throws FlojoDePapelesException {
		// TODO Auto-generated method stub
		return null;
	}





}
