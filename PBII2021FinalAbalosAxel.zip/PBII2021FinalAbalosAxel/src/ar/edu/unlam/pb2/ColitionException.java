package ar.edu.unlam.pb2;

public class ColitionException extends Exception {

	public static void method(MedioTransporte vehi1, MedioTransporte vehi2) throws ColitionException
	{
		if(vehi1.getLatitud().equals(vehi2.getLatitud())){
			if(vehi1.getLongitud().equals(vehi2.getLongitud())){
				
				 throw new ColitionException();
			}
			
		}
		 throw new ColitionException();
	
		
	}
}
